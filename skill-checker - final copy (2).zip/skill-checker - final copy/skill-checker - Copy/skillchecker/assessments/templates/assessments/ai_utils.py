import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def generate_ai_feedback(user_score, max_score, subskill_scores):
    prompt = f"""
    You are an expert skill coach. A user scored {user_score}/{max_score}.
    Subskill breakdown: {subskill_scores}.
    Give a short motivational performance summary and recommend what to improve.
    """

    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=200
    )

    return response.choices[0].message["content"].strip()

def explain_answer(question_text, correct_answer):
    prompt = f"""
    Question: {question_text}
    Correct Answer: {correct_answer}
    Explain in simple terms why this is correct.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150
    )
    return response.choices[0].message["content"].strip()
