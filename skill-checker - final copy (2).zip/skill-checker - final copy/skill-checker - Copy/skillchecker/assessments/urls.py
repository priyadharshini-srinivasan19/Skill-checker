from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    # Changed 'skill' to 'test' for consistency with updated model
    path('test/<int:test_id>/', views.test_details, name='test_details'),
    path('test/<int:test_id>/start/', views.start_test, name='start_test'),
    path('result/', views.assessment_result_view, name='assessment_result'),
    path('result/pdf/', views.assessment_pdf_view, name='assessment_pdf'),
    path('download_pdf/<uuid:session_id>/', views.download_pdf, name='download_pdf'),
    path('session/<uuid:session_id>/<int:index>/', views.take_test, name='take_test'),
    path('submit_test/<uuid:session_id>/', views.submit_test, name='submit_test'),
    path('test_result/<uuid:session_id>/', views.test_result, name='test_result'),
    path('review_answers/<uuid:session_id>/', views.review_answers, name='review_answers'),
    path("download_result_pdf/<int:result_id>/", views.download_result_pdf, name="download_result_pdf"),
    path('upload/', views.upload_questions, name='upload_questions'),
    path('submit_feedback/<uuid:session_id>/', views.submit_feedback, name='submit_feedback'),
    path('download-certificate/<int:result_id>/', views.download_certificate, name='download_certificate'),
    path('review_answers/<uuid:session_id>/', views.review_answers, name='review_answers'),
    path("review/<uuid:session_id>/", views.review_answers, name="review_answers"),
    path('test/<uuid:session_id>/', views.attempt_test, name='attempt_test'),
    path('test_result/<uuid:session_id>/', views.test_result, name='test_result'),
    path('review/<uuid:session_id>/', views.review_answers, name='review_answers'),
    path('download_certificate/<int:result_id>/', views.download_certificate, name='download_certificate'),
    path('certificate/<int:result_id>/', views.view_certificate, name='view_certificate'),
    



]
