
import uuid
from datetime import timedelta

from django.db import models
from django.db.models import UniqueConstraint
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone
from django.contrib.auth import get_user_model

User = get_user_model()


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


# ----------------------------
# Core Skill Models
# ----------------------------
class Skill(TimeStampedModel):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    logo = models.ImageField(upload_to='test_logos/')


    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Subskill(TimeStampedModel):
    skill = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='subskills')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    
    class Meta:
        ordering = ["name"]
        unique_together = ("skill", "name")

    def __str__(self):
        return f"{self.skill.name}: {self.name}"


class Question(TimeStampedModel):
    # Difficulty levels
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"

    LEVEL_CHOICES = [
        (BEGINNER, "Beginner"),
        (INTERMEDIATE, "Intermediate"),
        (ADVANCED, "Advanced"),
    ]

    # Question categories
    THEORY = "theory"
    PROBLEM = "problem"
    PROJECT = "project"
    ANY ="any"

    CATEGORY_CHOICES = [
        (THEORY, "Theory"),
        (PROBLEM, "Problem"),
        (PROJECT, "Project"),
        (ANY , "any"),
    ]

    # Question types
    MCQ = "mcq"
    MSQ = "msq"

    QUESTION_TYPE_CHOICES = [
        (MCQ, "Multiple Choice"),
        (MSQ, "Multiple Select"),
    ]

    # -------------------- MODEL FIELDS --------------------

    subskill = models.ForeignKey(Subskill, on_delete=models.CASCADE, related_name="questions")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default=THEORY)
    text = models.TextField(help_text="Main question text")
    explanation = models.TextField(blank=True, help_text="Optional explanation shown after answering")
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default=BEGINNER)
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPE_CHOICES, default=MCQ)
    
    code_snippet = models.TextField(blank=True, help_text="Optional code block for coding-based questions")
    

    class Meta:
        ordering = ["subskill", "level"]

    def __str__(self):
        return f"{self.subskill.name}: {self.text[:80]}..."

    @staticmethod
    def level_hierarchy(selected_level: str):
        """
        Returns all levels up to and including the selected level.
        Used for generating quizzes based on user level.
        """
        mapping = {
            Question.BEGINNER: [Question.BEGINNER],
            Question.INTERMEDIATE: [Question.BEGINNER, Question.INTERMEDIATE],
            Question.ADVANCED: [Question.BEGINNER, Question.INTERMEDIATE, Question.ADVANCED],
        }
        return mapping.get(selected_level.lower(), [Question.BEGINNER])


class AnswerOption(TimeStampedModel):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name="options")
    text = models.TextField()
    is_correct = models.BooleanField(default=False)

    class Meta:
        ordering = ["question", "id"]

    def __str__(self):
        return f"{self.question.id}: {self.text[:50]}... ({'✓' if self.is_correct else '✗'})"


'''
Class Test for conducting Tests
class Test(models.Model){
    # name
    # description
    # level
    # duration
    # num_questions
    # questions_per_page
    # image

}
''' 
class Test(models.Model):
    LEVEL_CHOICES = [
        ('beginner', 'Beginner'),
        ('intermediate', 'Intermediate'),
        ('advanced', 'Advanced'),
    ]
    name = models.CharField(max_length=200)
    skill = models.ForeignKey(Skill, on_delete=models.CASCADE, related_name='tests', null=True, blank=True)
    description = models.TextField(blank=True)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES, default='beginner')
    duration = models.IntegerField(default=5)
    questions_per_page = models.PositiveIntegerField(
        default=10, 
        help_text="Questions shown per page"
    )
    image = models.ImageField(upload_to='test_images/', blank=True, null=True)
    time_limit = models.PositiveIntegerField(
        default=5, 
        help_text="Time limit in minutes"
    )
    

    def __str__(self):
        return self.name

    @property
    def num_questions(self):
        """Return total questions from all configurations."""
        from .models import TestConfiguration
        return sum(config.num_questions for config in TestConfiguration.objects.filter(test=self))



# ----------------------------
# Test Configuration (optional)
# ----------------------------


class TestConfiguration(models.Model):
    test = models.ForeignKey("Test", on_delete=models.CASCADE, related_name="configurations")
    subskill = models.ForeignKey("Subskill", on_delete=models.CASCADE, related_name="test_configs")
    level = models.CharField(max_length=20, choices=Question.LEVEL_CHOICES)
    category = models.CharField(max_length=20, choices=Question.CATEGORY_CHOICES, default=Question.THEORY)
    num_questions = models.PositiveIntegerField(default=5)
    order = models.PositiveIntegerField(default=0) 

    class Meta:
        ordering = ["test", "order"]
    constraints = [
            models.UniqueConstraint(
            fields=["test", "subskill", "level", "category"],
            name="unique_test_subskill_level_category"
        )
    ]

# ----------------------------
# Test Session / Result
# ----------------------------

class TestSession(TimeStampedModel):
    # ──────────────── Status choices ────────────────
    IN_PROGRESS = "in_progress"
    COMPLETED   = "completed"
    ABANDONED   = "abandoned"

    STATUS_CHOICES = [
        (IN_PROGRESS, "In Progress"),
        (COMPLETED,   "Completed"),
        (ABANDONED,   "Abandoned"),
    ]

    # ──────────────── Core fields ────────────────
    session_id   = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user         = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    test         = models.ForeignKey(Test, on_delete=models.CASCADE, related_name="sessions")

    status       = models.CharField(max_length=20, choices=STATUS_CHOICES, default=IN_PROGRESS)
    started_at   = models.DateTimeField(default=timezone.now)
    completed_at = models.DateTimeField(null=True, blank=True)
    username = models.CharField(max_length=150, blank=True)
    feedback = models.TextField(blank=True, null=True)


    # ──────────────── Helpers ────────────────
    def __str__(self):
        username = self.user.username if self.user else "Anonymous"
        return f"{self.session_id} — {self.test.name} [{username}]"
    

class UserAnswer(models.Model):
    session = models.ForeignKey(TestSession, on_delete=models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    selected_option = models.ForeignKey(AnswerOption, null=True, blank=True, on_delete=models.SET_NULL)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.session.username} - {self.question.text[:30]} - {'Correct' if self.is_correct else 'Wrong'}"



class TestResult(models.Model):
    session = models.OneToOneField("TestSession", on_delete=models.CASCADE, related_name="result")
    score = models.IntegerField(default=0)
    max_score = models.IntegerField(default=0)
    percentage = models.FloatField(default=0)
    passed = models.BooleanField(default=False)
    time_taken = models.DurationField(null=True, blank=True)

    def __str__(self):
        return f"{self.session.username} - {self.percentage:.1f}%"

    
class TestFeedback(models.Model):
    session = models.ForeignKey(TestSession, on_delete=models.CASCADE, related_name="feedbacks")
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    rating = models.IntegerField(default=0, validators=[MinValueValidator(1), MaxValueValidator(5)])
    comments = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback for {self.session} - {self.rating}★"
    
class LearningResource(models.Model):
    CATEGORY_CHOICES = [
        ('learning', 'Learning Resource'),
        ('practice', 'Daily Practice'),
        ('roadmap', 'Skill Roadmap'),
        ('tools', 'Tools'),
    ]

    skill = models.ForeignKey(
        Skill,
        on_delete=models.CASCADE,
        related_name='resources',
        null=True,
        blank=True
    )
    description = models.TextField(blank=True)
    url = models.URLField()
    icon_class = models.CharField(max_length=50, default='bi-journal-code')
    platform_name = models.CharField(max_length=100, default='Resource')
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='learning')

    def __str__(self):
        return f"{self.skill.name if self.skill else 'No Skill'} - {self.platform_name}"


