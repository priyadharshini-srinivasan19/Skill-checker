# assessments/admin.py
from django.contrib import admin
from django.utils.html import format_html
from .models import (
    Skill,
    Subskill,
    Question,
    AnswerOption,
    TestConfiguration,
    Test,
    TestSession,
    UserAnswer,
    TestResult,
    TestFeedback,
    LearningResource,
)


# ────────────────────────────────────────────────
#  Core Skill Models
# ────────────────────────────────────────────────
@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):
    list_display = ("name", "description", "created_at")
    search_fields = ("name",)
    ordering = ("name",)

@admin.register(Subskill)
class SubskillAdmin(admin.ModelAdmin):
    list_display = ("name", "skill",)
    list_filter = ("skill",)
    search_fields = ("name",)
    ordering = ("skill__name",)


# ────────────────────────────────────────────────
#  Question & Answer
# ────────────────────────────────────────────────
class AnswerOptionInline(admin.TabularInline):
    model = AnswerOption
    extra = 1


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "short_text",
        "subskill",
        "level",
        "category",
        "question_type",
        "created_at",
    )
    list_filter = (
        "subskill__skill",
        "subskill",
        "level",
        "category",
        "question_type",
    )
    search_fields = ("text",)
    inlines = [AnswerOptionInline]

    @admin.display(description="Question")
    def short_text(self, obj):
        return (obj.text[:60] + "…") if len(obj.text) > 60 else obj.text


# ────────────────────────────────────────────────
#  Optional Test Config
# ────────────────────────────────────────────────


# ────────────────────────────────────────────────
#  Test Sessions & Results
# ────────────────────────────────────────────────
class UserAnswerInline(admin.StackedInline):
    model = UserAnswer
    extra = 0
    readonly_fields = ("question", "is_correct", "selected_options")
    can_delete = False


@admin.register(TestSession)
class TestSessionAdmin(admin.ModelAdmin):
    list_display = ['session_id', 'user', 'test', 'status', 'started_at', 'completed_at']
    list_filter = ['status', 'started_at', 'completed_at', 'test']
    search_fields = ['session_id', 'user__username'] 


@admin.register(TestResult)
class TestResultAdmin(admin.ModelAdmin):
    list_display = ('session', 'score', 'max_score', 'percentage', 'passed', 'time_taken')
    list_filter = ('passed',)
    search_fields = (
        'session__username',       # Search by candidate name
        'session__test__name',     # Search by test name
    )
    ordering = ('-percentage',)

@admin.register(Test)
class TestAdmin(admin.ModelAdmin):
    list_display = ('name', 'level', 'duration', 'time_limit', 'questions_per_page', 'num_questions_display', 'image_preview')
    list_filter = ('level',)
    search_fields = ('name',)

    readonly_fields = ('image_preview', 'num_questions_display')  # Preview and total questions

    def num_questions_display(self, obj):
        return obj.num_questions
    num_questions_display.short_description = "Total Questions"

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="height:60px;width:auto;border-radius:5px;" />', obj.image.url)
        return "No Image"
    image_preview.short_description = "Preview"

from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError
from .models import TestConfiguration

class TestConfigurationForm(forms.ModelForm):
    class Meta:
        model = TestConfiguration
        fields = "__all__"

    def clean(self):
        cleaned_data = super().clean()
        test = cleaned_data.get("test")
        subskill = cleaned_data.get("subskill")
        level = cleaned_data.get("level")
        category = cleaned_data.get("category")

        if test and subskill and level and category:
            exists = TestConfiguration.objects.filter(
                test=test,
                subskill=subskill,
                level=level,
                category=category,
            )

            if self.instance.pk:
                exists = exists.exclude(pk=self.instance.pk)

            if exists.exists():
                raise ValidationError("A configuration with this combination already exists.")

        return cleaned_data
@admin.register(TestConfiguration)
class TestConfigurationAdmin(admin.ModelAdmin):
    form = TestConfigurationForm
    list_display = ("test", "subskill", "level", "category", "num_questions", "order")
    list_filter = ("test", "subskill__skill", "level", "category")
    search_fields = ("test__name", "subskill__name")
    ordering = ("test", "order")

@admin.register(TestFeedback)
class TestFeedbackAdmin(admin.ModelAdmin):
    list_display = ('session', 'user', 'rating', 'created_at')
    search_fields = ('user__username', 'comments', 'session__session_id')
    list_filter = ('rating', 'created_at')
    readonly_fields = ('created_at',)


@admin.register(LearningResource)
class LearningResourceAdmin(admin.ModelAdmin):
    list_display = ('platform_name', 'skill', 'url', 'icon_class_display')
    list_filter = ('skill', 'platform_name')
    search_fields = ('platform_name', 'description', 'url', 'skill__name')

    # Optional: Display the icon visually in the admin list
    def icon_class_display(self, obj):
        return f'<i class="bi {obj.icon_class}"></i> {obj.icon_class}'
    icon_class_display.allow_tags = True
    icon_class_display.short_description = 'Icon'
