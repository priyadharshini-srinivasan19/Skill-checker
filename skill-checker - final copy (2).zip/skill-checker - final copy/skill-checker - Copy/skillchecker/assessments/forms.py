from django import forms
from .models import Question

from .models import AnswerOption

class testForm(forms.Form):
    def __init__(self, *args, **kwargs):
        questions = kwargs.pop('questions')
        super(testForm, self).__init__(*args, **kwargs)
        
        for question in questions:
            if question.question_type == 'MCQ':
                choices = [(a.id, a.text) for a in question.get_answers()]
                self.fields[f'question_{question.id}'] = forms.ChoiceField(
                    choices=choices,
                    widget=forms.RadioSelect,
                    label=question.text
                )
            elif question.question_type == 'TF':
                self.fields[f'question_{question.id}'] = forms.ChoiceField(
                    choices=[(True, 'True'), (False, 'False')],
                    widget=forms.RadioSelect,
                    label=question.text
                )
            elif question.question_type == 'FIB':
                self.fields[f'question_{question.id}'] = forms.CharField(
                    widget=forms.TextInput,
                    label=question.text,
                    required=False
                )

def generate_dynamic_form(questions):
    class DynamictestForm(forms.Form):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for question in questions:
                options = question.options.all()
                choices = [(option.id, option.text) for option in options]
                field_name = f"question_{question.id}"
                self.fields[field_name] = forms.ChoiceField(
                    label=question.text,
                    choices=choices,
                    widget=forms.RadioSelect,
                    required=True
                )

    return DynamictestForm()



class AnswerForm(forms.Form):
    def __init__(self, questions, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for question in questions:
            self.fields[f'question_{question.id}'] = forms.ChoiceField(
                label=question.text,
                choices=[(opt.id, opt.text) for opt in question.options.all()],
                widget=forms.RadioSelect,
                required=True
            )



class QuestionJSONUploadForm(forms.Form):
    json_file = forms.FileField(label="Upload Questions JSON File")
