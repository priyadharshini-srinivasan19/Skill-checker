import random
from collections import defaultdict
import uuid
import json
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator
from django.views.decorators.http import require_POST
from django.contrib import messages
from .models import TestFeedback
from django.utils import timezone
from django.db import transaction
from django.http import HttpResponse
from .decorators import no_cache
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib import colors
from django.template.loader import render_to_string
import xhtml2pdf  # type: ignore # or xhtml2pdf if you prefer
from .forms import QuestionJSONUploadForm
from xhtml2pdf import pisa
import io
from uuid import UUID
from datetime import datetime
from django.http import FileResponse, Http404
from .models import TestSession, UserAnswer, AnswerOption, Subskill, LearningResource,TestFeedback,TestResult
from django.shortcuts import get_object_or_404
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from .models import TestResult 
from django.views.decorators.cache import never_cache
from django.views.decorators.cache import cache_control
from io import BytesIO
import re
from django.db.models import Prefetch
from .models import (
    AnswerOption,
    Question,
    Skill,
    Subskill,
    TestResult,
    TestSession,
    Test,
    UserAnswer,
    TestConfiguration,
    TestFeedback,
)

# ---------- HOME ----------

def home(request):
    skills = Skill.objects.all()
    levels = ['beginner', 'intermediate', 'advanced']

    selected_skill_id = None
    selected_level = None
    tests = Test.objects.all()

    if request.method == 'POST':
        skill_val = request.POST.get('skill_id')
        level_val = request.POST.get('level')

        if skill_val:
            selected_skill_id = int(skill_val)
            tests = tests.filter(skill__id=selected_skill_id)  # ✅ Use skill__id

        if level_val:
            selected_level = level_val
            tests = tests.filter(level=selected_level)

    context = {
        'skills': skills,
        'levels':levels ,
        'tests': tests,
        'selected_skill_id': selected_skill_id,
        'selected_level': selected_level.capitalize() if selected_level else None,
    }
    return render(request, 'assessments/home.html', context)



# ---------- TEST DETAILS ----------
def test_details(request, test_id):
    test = get_object_or_404(Test, id=test_id)
    configs = test.configurations.select_related("subskill")
    covered = list({c.subskill for c in configs})

    return render(request, "assessments/test_details.html", {
        "test": test,
        "total_questions": test.num_questions,
        "subskills": covered,

    })


# ---------- START TEST (MULTI-CONFIG) ----------
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
import random, uuid
from .models import Test, TestConfiguration, Question, TestSession

def start_test(request, test_id):
    test = get_object_or_404(Test, id=test_id)

    if request.method == "POST":
        # ✅ Get name from form or use default "Candidate"
        username = request.POST.get("username", "").strip() or "Candidate"

        # ✅ Store the name in session
        request.session['username'] = username

        # ✅ Fetch configurations
        configurations = TestConfiguration.objects.filter(test=test).order_by("id")
        selected_questions = []

        for config in configurations:
            # Fetch questions for each configuration
            questions = list(
                Question.objects.filter(
                    subskill=config.subskill,
                    level=config.level,
                    category=config.category
                ).prefetch_related("options")
            )
            random.shuffle(questions)

            # Pick required number of questions
            selected_questions.extend(questions[:config.num_questions])

        # ✅ Remove duplicates while keeping order
        selected_questions = list(dict.fromkeys(selected_questions))

        if not selected_questions:
            messages.error(request, "No questions available for this test.")
            return redirect("test_details", test_id=test_id)

        # ✅ Create a test session
        session = TestSession.objects.create(
            test=test,
            user=request.user if request.user.is_authenticated else None,
            username=username,
            session_id=uuid.uuid4()
        )

        # ✅ Store question IDs in session (preserve order)
        request.session[f"qs_{session.session_id}"] = [q.id for q in selected_questions]

        # ✅ Redirect to the first question page
        return redirect("take_test", session_id=session.session_id, index=1)

    # GET request: show start page
    return render(request, "assessments/start_test.html", {"test": test})
# ──────────────────────────────
# TAKE TEST VIEW (Dynamic Pagination + Save Answers)
# ──────────────────────────────


@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def take_test(request, session_id, index=1):
    session = get_object_or_404(TestSession, session_id=session_id)

    if session.status == TestSession.COMPLETED:
        return redirect("test_result", session_id=session_id)

    # Get stored question IDs
    question_ids = request.session.get(f"qs_{session_id}", [])
    if not question_ids:
        messages.error(request, "No questions found for this session.")
        return redirect("start_test", test_id=session.test.id)

    # Get ordered questions
    questions = list(
        Question.objects.filter(id__in=question_ids).prefetch_related("options")
    )
    questions.sort(key=lambda q: question_ids.index(q.id))

    # Pagination
    per_page = session.test.questions_per_page or 5
    total_pages = (len(questions) + per_page - 1) // per_page
    start = (index - 1) * per_page
    end = start + per_page
    page_questions = questions[start:end]

    if request.method == "POST":
        for q in page_questions:
            key = f"question_{q.id}"
            selected_option_id = request.POST.get(key)

            if selected_option_id:
                selected_option = q.options.get(id=int(selected_option_id))
                UserAnswer.objects.update_or_create(
                    session=session,
                    question=q,
                    defaults={
                        "selected_option": selected_option,
                        "is_correct": selected_option.is_correct,
                    }
                )
            else:
                UserAnswer.objects.update_or_create(
                    session=session,
                    question=q,
                    defaults={
                        "selected_option": None,
                        "is_correct": False,
                    }
                )

        # Navigation
        if "next" in request.POST and index < total_pages:
            return redirect("take_test", session_id=session_id, index=index + 1)
        elif "prev" in request.POST and index > 1:
            return redirect("take_test", session_id=session_id, index=index - 1)
        elif "submit" in request.POST:
            return redirect("submit_test", session_id=session_id)

    answered = {
        ans.question.id: ans.selected_option.id if ans.selected_option else None
        for ans in UserAnswer.objects.filter(session=session, question__in=page_questions)
    }

    return render(request, "assessments/take_test.html", {
        "session": session,
        "questions": page_questions,
        "index": index,
        "total_pages": total_pages,
        "question_offset": start,
        "answered": answered,
        "duration_seconds": session.test.duration * 60 if hasattr(session.test, 'duration') else 300,
        "is_last_page": index == total_pages
    })

# ---------------- UPLOAD QUESTIONS ----------------
def upload_questions(request):
    if request.method == 'POST':
        form = QuestionJSONUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.cleaned_data['json_file']
            try:
                data = json.load(file)
                for q in data['questions']:
                    subskill = Subskill.objects.get(id=q['subskill_id'])

                    question = Question.objects.create(
                        subskill=subskill,
                        category=q['category'],
                        text=q['text'],
                        explanation=q.get('explanation', ''),
                        level=q['level'],
                        question_type=q['question_type'],
                        code_snippet=q.get('code_snippet', '')
                    )

                    for opt in q['options']:
                        AnswerOption.objects.create(
                            question=question,
                            text=opt['text'],
                            is_correct=opt['is_correct']
                        )

                return redirect('home')
            except Exception as e:
                form.add_error('json_file', f"Error processing file: {e}")
    else:
        form = QuestionJSONUploadForm()

    return render(request, 'assessments/upload_json.html', {'form': form})


# ---------------- SKILL TEST VIEW ----------------
def skill_test_view(request, skill_id):
    skill = get_object_or_404(Skill, id=skill_id)
    questions = Question.objects.filter(subskill__skill=skill).prefetch_related("options")

    return render(request, "assessments/test.html", {
        "skill": skill,
        "questions": questions
    })


@transaction.atomic
def save_page_answers(request, session_id, page_number):
    session = get_object_or_404(TestSession, session_id=session_id)

    # Get question IDs for this page from session
    question_ids = request.session.get(f"qs_page_{page_number}_{session_id}", [])
    questions = Question.objects.filter(id__in=question_ids)

    if request.method == "POST":
        for question in questions:
            selected_options = request.POST.getlist(f"question_{question.id}")

            # Remove old answers for this question in this session
            UserAnswer.objects.filter(session=session, question=question).delete()

            # Save new answers
            for option_id in selected_options:
                is_correct = question.options.filter(id=option_id, is_correct=True).exists()
                UserAnswer.objects.create(
                    session=session,
                    question=question,
                    selected_option_id=option_id,
                    is_correct=is_correct
                )

    # Move to the next page
    return redirect("take_test", session_id=session_id, page_number=page_number + 1)

# ---------- SUBMIT TEST ----------

@transaction.atomic
def submit_test(request, session_id):
    session = get_object_or_404(TestSession, session_id=session_id)

    # Prevent double submissions
    if hasattr(session, "result"):
        return redirect("test_result", session_id=session_id)

    # Get stored question order
    question_ids = request.session.get(f"qs_{session_id}", [])
    questions = list(Question.objects.filter(id__in=question_ids))

    # Save last page answers
    if request.method == "POST":
        for question in questions:
            selected_option_id = request.POST.get(f"question_{question.id}")

            UserAnswer.objects.filter(session=session, question=question).delete()

            if selected_option_id:
                is_correct = question.options.filter(
                    id=selected_option_id,
                    is_correct=True
                ).exists()
                UserAnswer.objects.create(
                    session=session,
                    question=question,
                    selected_option_id=selected_option_id,
                    is_correct=is_correct
                )

    # Fetch all saved answers
    answers = UserAnswer.objects.filter(session=session)
    score = sum(1 for ans in answers if ans.is_correct)
    max_score = len(questions)
    percentage = (score / max_score) * 100 if max_score > 0 else 0
    passed = percentage >= 70

    # Save result
    TestResult.objects.create(
        session=session,
        score=score,
        max_score=max_score,
        percentage=percentage,
        passed=passed,
        time_taken=timezone.now() - session.started_at,
    )

    # Update session status
    session.status = TestSession.COMPLETED
    session.completed_at = timezone.now()
    session.save()

    # Cleanup
    request.session.pop('test_session_id', None)

    return redirect("test_result", session_id=session_id)

@never_cache
def test_result(request, session_id):
    session = get_object_or_404(TestSession, session_id=session_id)
    result = getattr(session, "result", None)

    if not result:
        messages.error(request, "Result not available.")
        return redirect("home")

    # Fetch all user answers
    user_answers = (
        UserAnswer.objects
        .filter(session=session)
        .select_related('question', 'selected_option', 'question__subskill')
    )

    # Prepare answer data
    answers_data = []
    correct_count = 0
    total_questions = user_answers.count()

    for ua in user_answers:
        correct_option = AnswerOption.objects.filter(
            question=ua.question, is_correct=True
        ).first()

        if ua.is_correct:
            correct_count += 1

        answers_data.append({
            'question': ua.question,
            'selected_option': ua.selected_option,
            'is_correct': ua.is_correct,
            'correct_option': correct_option,
        })

    score_percentage = (correct_count / total_questions * 100) if total_questions else 0

    # Subskill-wise performance
    subskills = Subskill.objects.filter(test_configs__test=session.test).distinct()
    subskill_feedback = {}
    recommended_resources = {}

    for subskill in subskills:
        answers_for_subskill = [ua for ua in user_answers if ua.question.subskill == subskill]
        total = len(answers_for_subskill)
        correct = sum(1 for ua in answers_for_subskill if ua.is_correct)

        if total > 0:
            percent = (correct / total) * 100
            feedback = (
                "🎉 Strong in this area!" if percent >= 80 else
                "👍 Keep Learning, you’re improving!" if percent >= 60 else
                "🔍 Needs More Practice."
            )
        else:
            feedback = "⚪ Not attempted in this test."

        resources = LearningResource.objects.filter(skill=subskill.skill, category='learning')[:4]

        subskill_feedback[subskill] = {"correct": correct, "total": total, "feedback": feedback}
        recommended_resources[subskill] = resources

    daily_practice_resources = LearningResource.objects.filter(category='practice')[:4]
    roadmap_resources = LearningResource.objects.filter(category='roadmap')[:4]
    tool_resources = LearningResource.objects.filter(category='tools')[:4]

    username = request.session.get('username', '').strip()

    context = {
        "session": session,
        "result": result,
        "candidate_name": session.username or "Guest User",
        "answers": answers_data,
        "score_percentage": score_percentage,
        "subskills": subskills,
        "subskill_feedback": subskill_feedback,
        "recommended_resources": recommended_resources,
        "daily_practice_resources": daily_practice_resources,
        "roadmap_resources": roadmap_resources,
        "tool_resources": tool_resources,
        "username": username,
        "can_give_feedback": bool(username),
    }

    return render(request, "assessments/result.html", context)

# views.py
def review_answers(request, session_id):
    session = get_object_or_404(TestSession, session_id=session_id)
    question_ids = request.session.get(f"qs_{session_id}", [])

    if not question_ids:
        messages.error(request, "No questions found for this session.")
        return redirect("home")

    # Get all questions in the same order
    questions = list(
        Question.objects.filter(id__in=question_ids)
        .prefetch_related("options")
    )

    # Order according to stored sequence
    question_map = {q.id: q for q in questions}
    ordered_questions = [question_map[qid] for qid in question_ids if qid in question_map]

    answers = []
    for q in ordered_questions:
        selected_ids = UserAnswer.objects.filter(session=session, question=q).values_list("selected_option_id", flat=True)
        options = []
        for opt in q.options.all():
            options.append({
                "text": opt.text,
                "is_selected": opt.id in selected_ids,
                "is_correct": opt.is_correct
            })
        answers.append({"question": q, "options": options})

    stats = {
        "correct": UserAnswer.objects.filter(session=session, is_correct=True).count(),
        "wrong": UserAnswer.objects.filter(session=session, is_correct=False).count(),
        "skipped": len(question_ids) - UserAnswer.objects.filter(session=session).count(),
        "total": len(question_ids)
    }

    return render(request, "assessments/review_answers.html", {
        "session_id": session_id,
        "answers": answers,
        "stats": stats
    })


def sanitize_filename(name):
    return re.sub(r'[^\w\s-]', '', name).strip().replace(' ', '_')

def download_result_pdf(request, result_id):
    result = get_object_or_404(TestResult, id=result_id)
    session = result.session
    test = session.test

    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter

    # Title
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width / 2, height - 60, "Skill Assessment Report")

    # Horizontal line
    p.setLineWidth(0.5)
    p.line(50, height - 70, width - 50, height - 70)

    # Content
    p.setFont("Helvetica", 12)
    y = height - 110

    test_name = getattr(test, 'title', getattr(test, 'name', 'Unnamed Test'))
    p.drawString(50, y, f"Test Name: {test_name}"); y -= 20

    if hasattr(test, 'skill') and test.skill:
        p.drawString(50, y, f"Skill: {test.skill.name}"); y -= 20

    if hasattr(session, 'subskill') and session.subskill:
        p.drawString(50, y, f"Subskill: {session.subskill.name}"); y -= 20

    p.drawString(50, y, f"Score: {result.percentage}%"); y -= 20

    completed_at = session.completed_at.strftime('%Y-%m-%d %H:%M') if session.completed_at else "Not recorded"
    p.drawString(50, y, f"Completed At: {completed_at}"); y -= 20

    time_taken = str(result.time_taken) if result.time_taken else 'Not recorded'
    p.drawString(50, y, f"Time Taken: {time_taken}"); y -= 30

    if session.user:
        p.drawString(50, y, f"Candidate: {session.user.get_full_name() or session.user.username}"); y -= 20
        p.drawString(50, y, f"Email: {session.user.email}"); y -= 30

    # Footer
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(50, 50, "Generated by Skill Checker — Thank you for taking the assessment!")

    # Finalize
    p.showPage()
    p.save()
    buffer.seek(0)

    safe_name = sanitize_filename(test_name)
    return FileResponse(buffer, as_attachment=True, filename=f"Assessment_Result_{safe_name}.pdf")

@no_cache
def attempt_test(request, session_id):
    # Ensure session_id is valid UUID
    try:
        session_uuid = UUID(session_id, version=4)
    except ValueError:
        return redirect('home')

    # Get the session
    session = get_object_or_404(TestSession, session_id=session_uuid)


    # 🚫 Strict block: test already completed or result exists
    if session.status == TestSession.COMPLETED or hasattr(session, "result"):
        messages.warning(request, "You have already completed this test.")
        return redirect("test_result", session_id=session_id)
    # ✅ Block access if result already exists
    if TestResult.objects.filter(session=session).exists():
        test_result = TestResult.objects.get(session=session)
        return redirect('test_result', result_id=test_result.id)

    # ✅ Store session ID in user session to validate later (optional)
    request.session['test_session_id'] = str(session.session_id)

    # Load questions
    questions = Question.objects.filter(test=session.test).order_by('id')

    # Render your test page
    return render(request, 'assessments/attempt_test.html', {
        'session': session,
        'questions': questions
    })


def submit_feedback(request, session_id):
    if request.method == "POST":
        comments = request.POST.get("comments", "")
        rating = request.POST.get("rating", None)

        # Save feedback in DB
        TestFeedback.objects.create(
            session_id=session_id,
            comments=comments,
            rating=rating
        )

        return JsonResponse({"status": "success", "message": "Feedback saved."})

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

import imgkit
from django.http import HttpResponse
from django.template.loader import render_to_string

def download_certificate_image(request, result_id):
    result = get_object_or_404(TestResult, id=result_id)
    html = render_to_string('certificate_template.html', {'result': result})
    img = imgkit.from_string(html, False)  # returns image bytes

    response = HttpResponse(img, content_type='image/png')
    response['Content-Disposition'] = 'attachment; filename="certificate.png"'
    return response


def download_certificate(request, result_id):
    # Fetch the result
    result = get_object_or_404(TestResult, id=result_id)
    session = result.session
    test = session.test

    # ✅ Correct candidate name handling
    candidate_name = session.username or "Guest User"

    # Prepare PDF in memory
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=landscape(A4))
    width, height = landscape(A4)

    # ==== Gold Border ====
    p.setStrokeColorRGB(0.85, 0.65, 0.13)  # Gold
    p.setLineWidth(10)
    p.rect(20, 20, width - 40, height - 40)  # Outer border

    p.setLineWidth(4)
    p.rect(40, 40, width - 80, height - 80)  # Inner border

    # ==== Title ====
    p.setFont("Helvetica-Bold", 36)
    p.drawCentredString(width / 2, height - 120, "CERTIFICATE OF PARTICIPATION")

    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width / 2, height - 160, "Issued by Skill Checker")

    # ==== Recipient ====
    p.setFont("Helvetica-Oblique", 16)
    p.drawCentredString(width / 2, height - 210, "This certificate is presented to:")

    p.setFont("Helvetica-Bold", 32)
    p.drawCentredString(width / 2, height - 250, candidate_name)

    # ==== Test Info ====
    test_name = getattr(test, 'title', getattr(test, 'name', 'Unnamed Test'))
    score = f"{result.percentage:.0f}%"
    date_completed = session.completed_at.strftime('%B %d, %Y') if session.completed_at else "Unknown Date"

    p.setFont("Helvetica", 14)
    p.drawCentredString(width / 2, height - 290, f"For successfully completing the \"{test_name}\" assessment")
    p.drawCentredString(width / 2, height - 320, f"with a score of {score} on {date_completed}.")

    # ==== Signatures ====
    

    # ==== Footer ====
    p.setFont("Helvetica-Oblique", 10)
    p.setFillColor(colors.grey)
    p.drawCentredString(width / 2, 30, "Generated by Skill Checker - Thank you for using our platform!")

    # Finish PDF
    p.showPage()
    p.save()
    buffer.seek(0)

    return FileResponse(buffer, as_attachment=True, filename=f"SkillChecker_Certificate_{result.id}.pdf")


def result_view(request, session_id):
    session = get_object_or_404(TestSession, session_id=session_id)

    # Calculate correct/incorrect answers
    correct_answers = session.answers.filter(is_correct=True).count()
    total_questions = session.answers.count()
    incorrect_answers = total_questions - correct_answers

    # Calculate percentage
    percentage = round((correct_answers / total_questions) * 100) if total_questions > 0 else 0

    # Calculate time taken (if start_time and end_time exist)
    if session.start_time and session.end_time:
        time_taken = int((session.end_time - session.start_time).total_seconds())
    else:
        time_taken = 0

    # Get Result object (if exists)
    result = getattr(session, "result", None)  # assuming OneToOne with TestResult

    return render(request, "assessments/result.html", {
        "session": session,
        "percentage": percentage,
        "correct_answers": correct_answers,
        "incorrect_answers": incorrect_answers,
        "time_taken": time_taken,
        "result": result,
    })


def assessment_result_view(request):
    # Simulate actual data
    mastery_percentage = 85
    mastery_offset = 440 - (440 * mastery_percentage / 100)
    context = {
        'skill': 'Java Intermediate',
        'completed_date': datetime.now().strftime('%Y-%m-%d'),
        'completion_time': datetime.now().strftime('%I:%M %p'),
        'time_taken': '15 minutes',
        'correct_answers': 21,
        'total_questions': 25,
        'mastery_percentage': mastery_percentage,
        'mastery_offset': mastery_offset,
        'performance_text': 'Advanced',
        'performance_summary': 'Great work! You’ve mastered most Java concepts.',
        'username': request.user.username,
    }
    return render(request, 'result.html', context)

def assessment_pdf_view(request):
    # same context as the HTML view
    resp = io.BytesIO()

    p = canvas.Canvas(resp)
    # add text (you can style more)
    p.setFont('Helvetica-Bold', 16)
    p.drawString(50, 800, f"User: {request.user.username}")
    p.drawString(50, 780, "Java Intermediate Assessment Results")
    p.setFont('Helvetica', 12)
    y = 750
    for label, value in [
        ("Skill", "Java Intermediate"),
        ("Completed on", datetime.now().strftime('%Y-%m-%d')),
        ("Time", datetime.now().strftime('%I:%M %p')),
        ("Time taken", "15 minutes"),
        ("Correct", "21/25"),
        ("Mastery %", "85%"),
        ("Rating", "Advanced"),
    ]:
        p.drawString(50, y, f"{label}: {value}")
        y -= 20
    p.showPage()
    p.save()
    resp.seek(0)
    return FileResponse(resp, as_attachment=True, filename='assessment_result.pdf')

def filtered_questions_by_skill(request):
    skills = Skill.objects.all()
    questions = []
    selected_skill_id = None

    if request.method == 'POST':
        selected_skill_id = request.POST.get('skill_id')
        if selected_skill_id:
            questions = Question.objects.filter(subskill__skill__id=selected_skill_id)

    context = {
        'skills': skills,
        'questions': questions,
        'selected_skill_id': int(selected_skill_id) if selected_skill_id else None
    }
    return render(request, 'your_app/filtered_questions_by_skill.html', context)


def download_pdf(request, session_id):
    try:
        session = TestSession.objects.get(id=session_id)
        result = TestResult.objects.get(session=session)
    except (TestSession.DoesNotExist, TestResult.DoesNotExist):
        return HttpResponse("Result not found", status=404)

    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)

    p.setFont("Helvetica-Bold", 16)
    p.drawString(100, 800, "Skill Assessment Result")

    p.setFont("Helvetica", 12)
    p.drawString(100, 770, f"Session ID: {session.id}")
    p.drawString(100, 750, f"Score: {result.score} / {result.max_score}")
    p.drawString(100, 730, f"Percentage: {result.percentage:.2f}%")
    p.drawString(100, 710, f"Status: {'Passed' if result.passed else 'Failed'}")
    p.drawString(100, 690, f"Time Taken: {result.time_taken}")

    p.showPage()
    p.save()

    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf')

def view_certificate(request, result_id):
    # Fetch the result and related session/test
    result = get_object_or_404(TestResult, id=result_id)
    session = result.session
    test = session.test

    # ==== Safe candidate name (persistent, not request-based) ====
    # Priority: session.username -> user full name -> user username -> "Guest User"
    candidate_name = (
        session.username
        or (session.user.get_full_name() if session.user else None)
        or (session.user.username if session.user else None)
        or "Guest User"
    )

    # Prepare PDF in memory
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=landscape(A4))
    width, height = landscape(A4)

    # ==== Gold Border ====
    p.setStrokeColorRGB(0.85, 0.65, 0.13)  # gold color
    p.setLineWidth(10)
    p.rect(20, 20, width - 40, height - 40)
    p.setLineWidth(4)
    p.rect(40, 40, width - 80, height - 80)

    # ==== Title ====
    p.setFont("Helvetica-Bold", 36)
    p.drawCentredString(width / 2, height - 120, "CERTIFICATE OF PARTICIPATION")
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width / 2, height - 160, "Issued by Skill Checker")

    # ==== Recipient ====
    p.setFont("Helvetica-Oblique", 16)
    p.drawCentredString(width / 2, height - 210, "This certificate is presented to:")
    p.setFont("Helvetica-Bold", 32)
    p.drawCentredString(width / 2, height - 250, candidate_name)

    # ==== Test Info ====
    test_name = getattr(test, 'title', getattr(test, 'name', 'Unnamed Test'))
    score = f"{result.percentage:.0f}%"
    date_completed = (
        session.completed_at.strftime('%B %d, %Y')
        if session.completed_at
        else "Unknown Date"
    )

    p.setFont("Helvetica", 14)
    p.drawCentredString(
        width / 2,
        height - 290,
        f"For successfully completing the \"{test_name}\" assessment"
    )
    p.drawCentredString(
        width / 2,
        height - 320,
        f"with a score of {score} on {date_completed}."
    )

    # 

    # Finalize PDF
    p.showPage()
    p.save()
    buffer.seek(0)

    # ✅ Return as inline PDF (so it opens in browser)
    response = HttpResponse(buffer, content_type='application/pdf')
    response['Content-Disposition'] = 'inline; filename="SkillChecker_Certificate.pdf"'
    return response


def sanitize_filename(name):
    return re.sub(r'[^\w\s-]', '', name).strip().replace(' ', '_')

def download_result_pdf(request, result_id):
    result = get_object_or_404(TestResult, id=result_id)
    session = result.session
    test = session.test

    buffer = BytesIO()
    # Landscape A4 for certificate look
    p = canvas.Canvas(buffer, pagesize=landscape(A4))
    width, height = landscape(A4)

    # Colors and fonts
    p.setTitle("Skill Checker Certificate")

    # =============================
    # 1. Decorative Gold Borders
    # =============================
    from reportlab.lib import colors
    p.setStrokeColorRGB(0.85, 0.65, 0.13)  # Gold color
    p.setLineWidth(10)
    p.rect(20, 20, width-40, height-40)  # Outer border

    p.setLineWidth(4)
    p.rect(40, 40, width-80, height-80)  # Inner border

    # =============================
    # 2. Title
    # =============================
    p.setFont("Helvetica-Bold", 32)
    p.drawCentredString(width/2, height-120, "CERTIFICATE OF COMPLETION")

    # Website Name
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width/2, height-150, "Issued by Skill Checker")

    # =============================
    # 3. Recipient Name
    # =============================
    candidate_name = session.user.get_full_name() or session.user.username
    p.setFont("Helvetica-Oblique", 16)
    p.drawCentredString(width/2, height-200, "This certificate is presented to:")

    p.setFont("Helvetica-Bold", 30)
    p.drawCentredString(width/2, height-240, candidate_name)

    # =============================
    # 4. Details about Test
    # =============================
    test_name = getattr(test, 'title', getattr(test, 'name', 'Unnamed Test'))
    score = f"{result.percentage}%"

    p.setFont("Helvetica", 14)
    p.drawCentredString(width/2, height-280,
                        f"For successfully completing the \"{test_name}\" assessment")
    p.drawCentredString(width/2, height-310,
                        f"with a score of {score} on {session.completed_at.strftime('%B %d, %Y') if session.completed_at else 'Unknown Date'}.")

    # =============================
    # 5. Signature Area
    # =============================
 

    # =============================
    # 6. Footer
    # =============================
    p.setFont("Helvetica-Oblique", 10)
    p.setFillColor(colors.grey)
    p.drawCentredString(width/2, 30, "Generated by Skill Checker - Thank you for using our platform!")

    # Save PDF
    p.showPage()
    p.save()
    buffer.seek(0)

    safe_name = test_name.replace(" ", "_")
    return FileResponse(buffer, as_attachment=True, filename=f"SkillChecker_Certificate_{result.id}.pdf")