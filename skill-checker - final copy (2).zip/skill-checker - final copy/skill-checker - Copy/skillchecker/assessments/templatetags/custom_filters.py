from django import template
register = template.Library()

@register.filter
def get_item(d, key):
    return d.get(key)

@register.filter
def abs_value(value):
    try:
        return abs(value)
    except:
        return value
    

@register.filter
def get_item(dictionary, key):
    return dictionary.get(key)